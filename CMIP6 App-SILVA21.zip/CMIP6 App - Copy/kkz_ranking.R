# Determine the proper KKZ ranking system
library(ggplot2)

#Mode = function(x){ # Gathers the modal string value
#  ta = table(x)
#  tam = max(ta)
#  if (all(ta == tam))
#    mod = NA
#  else
#    if(is.numeric(x))
#      mod = as.numeric(names(ta)[ta == tam])
#  else
#    mod = names(ta)[ta == tam]
#  return(mod)
#}

setwd('Y:/ByUser/Mike_B/CMIP6 App') # set directory
temp <- list.files(pattern = 'change*') # Access all files that begin with "change"

for(item in 1:length(temp)){
  data <- read.csv(temp[item],header=T)
  d <- data[3:282,] # Access only relevant information
  
  d.agg <- aggregate(d[5:40],by=list(d$gcm,d$scenario),FUN = 'mean')
  
  # Create new columns representative of select sections of the year
  d.agg$Precipitation <- rowMeans(d.agg[c(27:38)]) #Nov to June
  d.agg$TMax <- rowMeans(d.agg[c(3:14)]) # May to Oct
  d.agg$TMin <- rowMeans(d.agg[c(15:26)]) # May to Oct
  
  df <- split(d.agg,d.agg$Group.2) # Create a series of lists dividing each ssp
  
  # SSP126
  cX <- mean(c(max(df$ssp126$TMax),min(df$ssp126$TMax)))
  cY <- mean(c(max(df$ssp126$Precipitation),min(df$ssp126$Precipitation)))
  ggplot(df$ssp126,aes(x=TMax,y=Precipitation)) +geom_point() +
    geom_text(aes(label = Group.1),size=3) + geom_point(aes(x=cX,y=cY),color='red',size=4) 
  
  df$ssp126$dist <- sqrt(((df$ssp126$TMax-cX)^2) + ((df$ssp126$Precipitation-cY)^2))
  # SSP245
  cX <- mean(c(max(df$ssp245$TMax),min(df$ssp245$TMax)))
  cY <- mean(c(max(df$ssp245$Precipitation),min(df$ssp245$Precipitation)))
  ggplot(df$ssp245,aes(x=TMax,y=Precipitation)) +geom_point() +
    geom_text(aes(label = Group.1),size=3) + geom_point(aes(x=cX,y=cY),color='red',size=4)
  
  df$ssp245$dist <- sqrt(((df$ssp245$TMax-cX)^2) + ((df$ssp245$Precipitation-cY)^2))
  # SSP370
  cX <- mean(c(max(df$ssp370$TMax),min(df$ssp370$TMax)))
  cY <- mean(c(max(df$ssp370$Precipitation),min(df$ssp370$Precipitation)))
  ggplot(df$ssp370,aes(x=TMax,y=Precipitation)) +geom_point() +
    geom_text(aes(label = Group.1),size=3) + geom_point(aes(x=cX,y=cY),color='red',size=4)
  
  df$ssp370$dist <- sqrt(((df$ssp370$TMax-cX)^2) + ((df$ssp370$Precipitation-cY)^2))
  # SSP585
  cX <- mean(c(max(df$ssp585$TMax),min(df$ssp585$TMax)))
  cY <- mean(c(max(df$ssp585$Precipitation),min(df$ssp585$Precipitation)))
  ggplot(df$ssp585,aes(x=TMax,y=Precipitation)) +geom_point() +
    geom_text(aes(label = Group.1),size=3) + geom_point(aes(x=cX,y=cY),color='red',size=4)
  
  df$ssp585$dist <- sqrt(((df$ssp585$TMax-cX)^2) + ((df$ssp585$Precipitation-cY)^2))
  
  # Create rankings
  kkzRank <- as.data.frame(c(1:14))
  kkzRank$Annual_ssp126 <- df$ssp126$Group.1[order(df$ssp126$dist,decreasing=T)]
  kkzRank$Annual_ssp245 <- df$ssp245$Group.1[order(df$ssp245$dist,decreasing=T)]
  kkzRank$Annual_ssp370 <- df$ssp370$Group.1[order(df$ssp370$dist,decreasing=T)]
  kkzRank$Annual_ssp585 <- df$ssp585$Group.1[order(df$ssp585$dist,decreasing=T)]
  for(i in 2:5){
    kkzRank[i] <- kkzRank[c(14,1:13),i]
  }
  
  ##### Create a table presenting all scenarios
  d.seasonal <- aggregate(d[41:52],by=list(d$gcm,d$scenario),FUN = 'mean')
  d.seasonal.names <- as.data.frame(d.seasonal$Group.1[c(1:14)])
  
  a <- c(3:6)
  b <- c(1,15,29,43)
  c <- 6
  for(i in b){
    for(j in a){
      df.Sdata <- d.seasonal[c(i:(i+13)),]
      cX <- mean(c(max(df.Sdata[j]),min(df.Sdata[j])))
      cXmin <- mean(c(max(df.Sdata[j+4]),min(df.Sdata[j+4])))
      cY <- mean(c(max(df.Sdata[j+8]),min(df.Sdata[j+8])))
      d.seasonal.names$resMax <- sqrt(((df.Sdata[j]-cX)^2) + ((df.Sdata[j+8]-cY)^2))
      d.seasonal.names$resMin <- sqrt(((df.Sdata[j+4]-cX)^2) + ((df.Sdata[j+8]-cY)^2))
      d.seasonal.order <- d.seasonal.names$`d.seasonal$Group.1[c(1:14)]`[order(d.seasonal.names[2],decreasing=T)]
      kkzRank[c] <-d.seasonal.order[c(14,1:13)]
      names(kkzRank)[c] <- paste(df.Sdata$Group.2[1],names(df.Sdata[j]),sep="")
      d.seasonal.order <- d.seasonal.names$`d.seasonal$Group.1[c(1:14)]`[order(d.seasonal.names[3],decreasing=T)]
      kkzRank[c+1] <- d.seasonal.order[c(14,1:13)]
      names(kkzRank)[c+1] <- paste(df.Sdata$Group.2[1],names(df.Sdata[j+4]),sep="_")
      c <- c+2
    }
  }
}
kkzRankings <- mget(ls(pattern="kkzRankchange"))
kkzNames <- names(kkzRankings)
kkzNames <- gsub("kkzRankchange.","",kkzNames)
names(kkzRankings) <- gsub(".csv","",kkzNames)

write.csv(kkzRankings, file="kkzRanking.csv")



